rootProject.name = "PipReaper"
include(":app")
